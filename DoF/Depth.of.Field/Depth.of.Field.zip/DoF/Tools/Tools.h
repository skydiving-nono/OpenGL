//
//  Tools.h
//  DoF
//
//
//  Created by Anthony Walker


#import <Foundation/Foundation.h>

@interface Tools : NSObject

//-(void) writeImagsToFile;
//
//-(UIImage*) screenshot;

+ (void) imageBlend;
+ (UIImage *) glViewScreenshot;

@end
